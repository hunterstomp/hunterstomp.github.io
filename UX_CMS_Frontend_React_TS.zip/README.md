# UX CMS Frontend (React + TypeScript)

## Setup
```bash
npm install
npm run dev
```

## Features
- Connects to Sanity project `q5gam10s`
- Lists case studies with persona access
