# UX Case Study CMS Starter (Sanity.io + Vite + React)

This project is a portfolio CMS for UX case studies using Sanity.io (headless CMS) and Vite + React as frontend.

## 📦 Included
- Sanity Studio schema (for UX case studies)
- React frontend with routing, gallery, and sidebar
- NDA gate with password-based access
- Persona support: Guest, VIP, Author

## 🚀 How to Use

### 1. Sanity Setup
```bash
npm install -g @sanity/cli
sanity init --template clean
# Replace /schemas/caseStudy.js with provided version
```

### 2. Frontend Setup
```bash
cd ux-frontend
npm install
npm run dev
```

### 3. Deployment
Deploy via Vercel, Netlify, or your own server.
