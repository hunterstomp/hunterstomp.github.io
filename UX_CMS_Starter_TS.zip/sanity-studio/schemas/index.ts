import { defineType, defineArrayMember } from 'sanity'
import caseStudy from './caseStudy'

export const schemaTypes = [caseStudy]
